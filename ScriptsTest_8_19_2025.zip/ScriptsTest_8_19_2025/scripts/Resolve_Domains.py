##########################
# Script by Manu Gonzalez (mgonzalez@infoblox.com), Joaquin Gómez (jgomez@infoblox.com)
# Script edited and changed by Zachary Miszkiewicz (zmiszkiewicz@infoblox.com)
# Infoblox.com
##########################
def main(input_files, sinkholes, amount, timeout_amount):
    import socket
    import csv
    import os
    import sys
    import random
    import threading
    import json

    OK = "ALLOWED"
    NOT_OK = "BLOCKED"
    

    def resolve_host(hostname, result_container):
        try:
            result_container.append(socket.gethostbyname(hostname))
        except Exception as e:
            result_container.append(e)

    def gethostbyname_with_timeout(hostname, timeout=5):
        result = []
        thread = threading.Thread(target=resolve_host, args=(hostname, result))
        thread.start()
        thread.join(timeout)

        if thread.is_alive():
            raise socket.timeout(f"Query timed out after {timeout} seconds")

        if isinstance(result[0], Exception):
            raise result[0]
        
        return result[0]

    def random_sample(lst, num):
        # Get the user specified amount of domains out of the list of domains
        if amount >= len(lst):
            return lst
        return random.sample(lst, num)


    def resolve_domains(domain_list, output_filename, ip_base, suffixes, sinkhole, timeout_num):
        # We generate the list of ip that we will change from "OK" to "NOT" because it's related to sinkholing.
        sinkhole_ips = set([ip_base + "61." + str(i) for i in suffixes] + 
                            [ip_base + "48." + str(i) for i in suffixes])
        for i in sinkhole:
            sinkhole_ips.add(i)
        results = []

        # Nomber of domains resolved and not resolved
        resolved_domains = 0
        unresolved_domains = 0


        # Initialize Progress Bar
        input_file = output_filename[:-12]
        bar_length = 50
        counter = 0
        total = len(domain_list)

        print(f"\n\nStarting to query domains from {os.path.basename(input_file)}")
        socket.setdefaulttimeout(1)
        for domain in domain_list:
            # Progress Bar
            progress = counter / total  
            block = int(progress * bar_length)
            sys.stdout.write(f"\rProgress: [{'#' * block:<{bar_length}}] {int(progress * 100)}%")
            sys.stdout.flush()

            temp_obj = {"Name": domain.replace('.', '[.]'), "IPAddress": "", "Status": "", "Property": "", "Notes": "", "ErrorMessage": ""}
            try:
                # Get host information (IPADDRESS)
                ip_address = gethostbyname_with_timeout(domain, timeout_num)

                temp_obj["IPAddress"] = ip_address
                temp_obj["Status"] = OK
                if ip_address in sinkhole_ips:
                    temp_obj["Status"] = NOT_OK
            except socket.gaierror as e:
                temp_obj["Status"] = NOT_OK
                temp_obj["ErrorMessage"] = str(e)
            except socket.timeout as e:
                temp_obj["Status"] = NOT_OK
                temp_obj["ErrorMessage"] = str(e)
            try:
                temp_obj["Property"] = domain_information[domain]['property']
                temp_obj["Notes"] = domain_information[domain]['notes']
            except:
                temp_obj["Property"] = ""
                temp_obj["Notes"] = ""
            results.append(temp_obj)
            if temp_obj["Status"] == OK:
                resolved_domains += 1
            else:
                unresolved_domains += 1

            counter += 1
        sys.stdout.write(f"\rProgress: [{'#' * 50}] 100%")
        sys.stdout.flush()
        print(f"\nAll {total} domains queried from {os.path.basename(input_file)}\n")

        # It prints the results in CSV file
        with open(output_filename, 'w', newline='') as csvfile:
            fieldnames = ["Name", "IPAddress", "Status", "ErrorMessage", "Property", "Notes"]
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(results)
            # It prints summary when processing of each file is done
            print(f"File: {output_filename}")
            print(f"Total Domains resolved: {resolved_domains}")
            print(f"Total Domains not resolved: {unresolved_domains}")

    # Sinkholing config: List of IP related to Sinkholes
    ip_base = "146.112."
    suffixes = range(1, 255)
    json_file = os.path.join(os.path.join(os.getcwd(), 'files'), 'domain_info.json')
    domain_information = {}
    try:
        with open(json_file, 'r') as f:
            domain_information = json.load(f)
    except:
        print("Error Processing JSON File, Results Will Not Have Property or Notes")


    folder_path = os.path.join(os.getcwd(), 'results')
    # Check if the folder exists
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
    for domain_file in input_files:
        # We create the name of output file based on the input file name
        name = os.path.splitext(os.path.basename(domain_file))[0]
        output_file = name + "_results.csv"
        output_file = os.path.join(folder_path, output_file)
        # We check the list of domains in each list
        try:
            with open(domain_file, 'r') as f:
                domains = f.readlines()
                domains = [domain.strip() for domain in domains]
        except FileNotFoundError:
            print(f"Error: Domain file '{domain_file}' Not found.")
            continue
        
        domains = random_sample(domains, amount)

        # Main function to be called
        resolve_domains(domains, output_file, ip_base, suffixes, sinkholes, timeout_amount)

        print(f"Results in '{output_file}'.")


