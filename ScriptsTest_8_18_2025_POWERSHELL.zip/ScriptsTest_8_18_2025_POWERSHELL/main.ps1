# main.ps1
# Main entry point. It mimics the original main.py by calling functions from helper and other modules.

# Dot-source helper and module scripts
. "$PSScriptRoot\scripts\helper.ps1"
. "$PSScriptRoot\scripts\Resolve_Domains.ps1"
. "$PSScriptRoot\scripts\Sinkholing_Out.ps1"
. "$PSScriptRoot\scripts\Finalized_Results.ps1"

# Get list of input files from the "files" folder.
$inputFiles = Get-InputFiles -FolderName "files"
if ($inputFiles.Count -eq 0) {
    Write-Host "No input files found in 'files' folder."
    exit
}

# Ask user for sinkholes.
$sinkholes = Get-Sinkholes

# Ask for timeout amount.
$timeout = Ask-ForTimeout

# Let the user choose which test file(s) to run.
$selectedFiles = Choose-Test -InputFiles $inputFiles

# Ask for how many domains to query.
$amount = Ask-ForAmount

# Begin Query Process (resolving domains).
Resolve-DomainsModule -InputFiles $selectedFiles -Sinkholes $sinkholes -Amount $amount -Timeout $timeout

# Process CSV files to change sinkholes to BLOCKED.
Sinkholing-Out -Sinkholes $sinkholes

# Gather overall statistics from the CSV results.
Finalized-Results
