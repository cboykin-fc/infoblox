# Resolve_Domains.ps1
# Contains functions to resolve domain names with a timeout, sample the list of domains,
# and export results to CSV files in a "results" folder.

function Get-HostByNameWithTimeout {
    param(
        [string]$Domain,
        [int]$Timeout
    )
    try {
        $asyncResult = [System.Net.Dns]::BeginGetHostEntry($Domain, $null, $null)
        if ($asyncResult.AsyncWaitHandle.WaitOne($Timeout * 1000)) {
            $hostEntry = [System.Net.Dns]::EndGetHostEntry($asyncResult)
            # Get the first IPv4 address
            $ip = ($hostEntry.AddressList | Where-Object { $_.AddressFamily -eq [System.Net.Sockets.AddressFamily]::InterNetwork }) | Select-Object -First 1
            if ($ip -eq $null) {
                throw "No IPv4 address found"
            }
            return $ip.IPAddressToString
        }
        else {
            throw "Query timed out after $Timeout seconds"
        }
    }
    catch {
        throw $_.Exception.Message
    }
}

function Get-RandomSample {
    param(
        [array]$List,
        [int]$Num
    )
    if ($Num -ge $List.Count) {
        return $List
    }
    return $List | Get-Random -Count $Num
}

function Resolve-Domains {
    param(
        [array]$DomainList,
        [string]$OutputFilename,
        [string]$IpBase,
        [int[]]$Suffixes,
        [array]$Sinkholes,
        [int]$Timeout,
        $DomainInfo
    )
    # Build sinkhole IP set (146.112.61.* and 146.112.48.*) plus any user provided sinkholes.
    $sinkholeIps = New-Object System.Collections.Generic.HashSet[string]
    foreach ($s in $Suffixes) {
        $sinkholeIps.Add("$IpBase" + "61.$s") | Out-Null
        $sinkholeIps.Add("$IpBase" + "48.$s") | Out-Null
    }
    foreach ($s in $Sinkholes) {
        $sinkholeIps.Add($s) | Out-Null
    }

    $results = @()
    $resolvedCount = 0
    $unresolvedCount = 0
    $total = $DomainList.Count
    $counter = 0

    Write-Host "`nStarting to query domains from $(Split-Path $OutputFilename -Leaf)"
    
    foreach ($domain in $DomainList) {
        $counter++
        $percentComplete = ($counter / $total) * 100
        Write-Progress -Activity "Resolving domains" -Status "Processing $counter of $total ($([math]::Round($percentComplete,2))%)" -PercentComplete $percentComplete

        $tempObj = [PSCustomObject]@{
            Name         = $domain -replace '\.', '[.]'
            IPAddress    = ""
            Status       = ""
            ErrorMessage = ""
            Property     = ""
            Notes        = ""
        }
        try {
            $ipAddress = Get-HostByNameWithTimeout -Domain $domain -Timeout $Timeout
            $tempObj.IPAddress = $ipAddress
            $tempObj.Status = "ALLOWED"
            if ($sinkholeIps.Contains($ipAddress)) {
                $tempObj.Status = "BLOCKED"
            }
            $resolvedCount++
        }
        catch {
            $tempObj.Status = "BLOCKED"
            $tempObj.ErrorMessage = $_
            $unresolvedCount++
        }
        if ($DomainInfo -and $DomainInfo.$domain) {
            $tempObj.Property = $DomainInfo.$domain.property
            $tempObj.Notes = $DomainInfo.$domain.notes
        }
        $results += $tempObj
    }
    Write-Progress -Activity "Resolving domains" -Status "Completed" -Completed

    Write-Host "`nAll $total domains queried."

    # Save the results to a CSV file.
    $results | Export-Csv -Path $OutputFilename -NoTypeInformation
    Write-Host "Results saved in '$OutputFilename'."
    Write-Host "Total Domains resolved: $resolvedCount"
    Write-Host "Total Domains not resolved: $unresolvedCount"
}

function Resolve-DomainsModule {
    param(
        [array]$InputFiles,
        [array]$Sinkholes,
        [int]$Amount,
        [int]$Timeout
    )
    $IpBase = "146.112."
    $Suffixes = 1..254

    # Load domain info from JSON if available.
    $domainInfoPath = Join-Path -Path (Join-Path -Path (Get-Location) -ChildPath "files") -ChildPath "domain_info.json"
    $domainInfo = $null
    if (Test-Path $domainInfoPath) {
        try {
            $jsonContent = Get-Content $domainInfoPath -Raw
            $domainInfo = ConvertFrom-Json $jsonContent
        }
        catch {
            Write-Host "Error processing JSON file, results will not have Property or Notes"
        }
    }
    
    # Create the "results" directory if it does not exist.
    $resultsDir = Join-Path -Path (Get-Location) -ChildPath "results"
    if (!(Test-Path $resultsDir)) {
        New-Item -ItemType Directory -Path $resultsDir | Out-Null
    }

    foreach ($domainFile in $InputFiles) {
        $name = [System.IO.Path]::GetFileNameWithoutExtension($domainFile)
        $outputFile = Join-Path -Path $resultsDir -ChildPath ("{0}_results.csv" -f $name)
        try {
            $domains = Get-Content $domainFile | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne "" }
        }
        catch {
            Write-Host "Error: Domain file '$domainFile' not found."
            continue
        }
        $selectedDomains = Get-RandomSample -List $domains -Num $Amount
        Resolve-Domains -DomainList $selectedDomains -OutputFilename $outputFile -IpBase $IpBase -Suffixes $Suffixes -Sinkholes $Sinkholes -Timeout $Timeout -DomainInfo $domainInfo
    }
}
