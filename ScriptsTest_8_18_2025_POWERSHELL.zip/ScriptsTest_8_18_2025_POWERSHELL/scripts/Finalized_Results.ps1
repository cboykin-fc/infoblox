# Finalized_Results.ps1
# Contains functions to gather statistics from all result CSV files and output a summary CSV.

function Get-UniqueFileName {
    param(
        [string]$FilePath
    )
    $fileName = [System.IO.Path]::GetFileNameWithoutExtension($FilePath)
    $fileExt = [System.IO.Path]::GetExtension($FilePath)
    $directory = [System.IO.Path]::GetDirectoryName($FilePath)
    $counter = 1
    while (Test-Path $FilePath) {
        $FilePath = Join-Path -Path $directory -ChildPath ("{0}_{1}{2}" -f $fileName, $counter, $fileExt)
        $counter++
    }
    return $FilePath
}

function Finalized-Results {
    $resultsDir = Join-Path -Path (Get-Location) -ChildPath "results"
    if (!(Test-Path $resultsDir)) {
        Write-Host "The folder 'results' does not exist."
        return
    }
    $fileStats = @{}

    $csvFiles = Get-ChildItem -Path $resultsDir -Filter *.csv | Where-Object { $_.Name -notmatch "^statistics" }
    foreach ($csvFile in $csvFiles) {
        $rows = Import-Csv -Path $csvFile.FullName
        $allowed = 0
        $blocked = 0
        foreach ($row in $rows) {
            if ($row.Status -eq "ALLOWED") {
                $allowed++
            }
            elseif ($row.Status -eq "BLOCKED") {
                $blocked++
            }
        }
        $totalRows = $allowed + $blocked
        if ($totalRows -gt 0) {
            $percentAllowed = ($allowed / $totalRows) * 100
            $percentBlocked = ($blocked / $totalRows) * 100
        }
        else {
            $percentAllowed = 0
            $percentBlocked = 0
        }
        $fileStats[$csvFile.Name] = [PSCustomObject]@{
            File                 = $csvFile.Name
            Allowed              = $allowed
            Blocked              = $blocked
            "Percentage Allowed" = "{0:N2}%" -f $percentAllowed
            "Percentage Blocked" = "{0:N2}%" -f $percentBlocked
        }
    }
    $outputFile = Join-Path -Path (Get-Location) -ChildPath "statistics.csv"
    if (Test-Path $outputFile) {
        $outputFile = Get-UniqueFileName -FilePath $outputFile
    }
    $fileStats.Values | Export-Csv -Path $outputFile -NoTypeInformation
    Write-Host "Statistics saved in $outputFile"
}
