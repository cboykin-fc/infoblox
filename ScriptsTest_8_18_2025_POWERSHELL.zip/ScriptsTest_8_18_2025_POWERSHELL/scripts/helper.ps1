# helper.ps1
# Contains helper functions for file listing and user interaction.

function Get-InputFiles {
    param(
        [string]$FolderName
    )
    $folderPath = Join-Path -Path (Get-Location) -ChildPath $FolderName
    if (!(Test-Path $folderPath)) {
        Write-Host "The folder '$FolderName' does not exist."
        return @()
    }
    # Get .txt files only
    $files = Get-ChildItem -Path $folderPath -Filter *.txt -File | Select-Object -ExpandProperty FullName
    return $files
}

function Ask-ForTimeout {
    $default = 5
    $input = Read-Host "`nHow long would you like the Timeout set to (press enter for default of $default seconds)?"
    $input = $input.Trim()
    if ($input -eq "") {
        return $default
    }
    while (-not ($input -as [int] -and [int]$input -gt 0)) {
        $input = Read-Host "Please provide a number above 0"
        $input = $input.Trim()
    }
    return [int]$input
}

function Ask-ForAmount {
    $input = Read-Host "`nHow many domains would you like to test (1-1000)?"
    $input = $input.Trim()
    while (-not ($input -as [int] -and [int]$input -ge 1 -and [int]$input -le 1000)) {
        $input = Read-Host "Please provide a number between 1-1000"
        $input = $input.Trim()
    }
    return [int]$input
}

function Choose-Test {
    param(
        [array]$InputFiles
    )
    Write-Host "Here are the available test(s) to run:`n"
    $count = 1
    foreach ($file in $InputFiles) {
        Write-Host "$count. $(Split-Path $file -Leaf)"
        $count++
    }
    $userInput = Read-Host "`nPlease type the number corresponding to the test you would like to run, press enter for all tests"
    $userInput = $userInput.Trim()
    if ($userInput -eq "") {
        return $InputFiles
    }
    while (-not ($userInput -as [int] -and [int]$userInput -ge 1 -and [int]$userInput -lt $count)) {
        $userInput = Read-Host "Please select a valid number"
        $userInput = $userInput.Trim()
    }
    $index = [int]$userInput - 1
    return @($InputFiles[$index])
}

function Get-Sinkholes {
    $allSinkholes = @()
    while ($true) {
        $sinkhole = Read-Host "`nPlease provide any sinkholes by typing them out below (Press enter to move on)"
        if ($sinkhole.Trim() -eq "") {
            break
        }
        Write-Host "Does this look correct: $sinkhole"
        $confirm = Read-Host "(y/n)"
        $confirm = $confirm.ToLower().Trim()
        while ($confirm -notin @("y", "n", "yes", "no")) {
            $confirm = Read-Host "Please use (y/n)"
            $confirm = $confirm.ToLower().Trim()
        }
        if ($confirm -in @("y", "yes")) {
            $allSinkholes += $sinkhole
        }
    }
    return $allSinkholes
}