# Sinkholing_Out.ps1
# Contains functions to iterate over the CSV result files and update rows where the IP matches a sinkhole.

function Sinkholing-Out {
    param(
        [array]$Sinkholes
    )
    $resultsDir = Join-Path -Path (Get-Location) -ChildPath "results"
    if (!(Test-Path $resultsDir)) {
        Write-Host "The folder 'results' does not exist."
        return
    }
    $IpBase = "146.112."
    $Suffixes = 1..254
    $sinkholeIp = @()
    foreach ($s in $Suffixes) {
        $sinkholeIp += "$IpBase" + "61.$s"
        $sinkholeIp += "$IpBase" + "48.$s"
    }
    $sinkholeIp += $Sinkholes

    function Change-CellValues {
        param(
            [string]$CsvFile
        )
        $rows = Import-Csv -Path $CsvFile
        foreach ($row in $rows) {
            $ips = $row.IPAddress -split ","
            if ($row.Status -eq "ALLOWED" -and ($ips | ForEach-Object { $_.Trim() } | Where-Object { $sinkholeIp -contains $_ })) {
                $row.Status = "BLOCKED"
            }
        }
        $rows | Export-Csv -Path $CsvFile -NoTypeInformation
        Write-Host "Cells have been updated in $CsvFile"
    }

    Get-ChildItem -Path $resultsDir -Filter *.csv | ForEach-Object {
        Change-CellValues -CsvFile $_.FullName
    }
    Write-Host "Process complete."
}