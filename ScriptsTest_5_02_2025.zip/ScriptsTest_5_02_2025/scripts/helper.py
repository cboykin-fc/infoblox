##########################
# Script by Zachary Miszkiewicz (zmiszkiewicz@infoblox.com)
# Infoblox.com
##########################


import os

def list_files(folder_name):
    # Gathers names of the files in the 'files' folder
    try:
        folder_path = os.path.join(os.getcwd(), folder_name)
        file_list = os.listdir(folder_path)
        files_only = [os.path.join(folder_path,f) for f in file_list if (os.path.isfile(os.path.join(folder_path, f)) and f.endswith(".txt"))]
        return files_only
    except FileNotFoundError:
        return f"The folder '{folder_name}' does not exist."

def ask_for_timeout():
    print("\nHow long would you like the Timeout set to (press enter for default of 5 seconds)?: ", end="")

    num = input()
    num = num.strip()
    if num == "":
         return 5
    while True:
        if num.isdigit() and (0 < int(num)):
                    return int(num)
        else:
             num = input("Please provide a number above 0: ")
             num = num.strip()


def main(input_files):

    print("Here are the available test(s) to run:\n")
    count = 1
    for i in input_files:
        print(count, end=". ")
        print(os.path.basename(i))
        count += 1
    
    print("\nPlease type the number corresponding to the test you would like to run, press enter for all tests: ", end="")
    user_input = input()
    return_value = 'no'
    while return_value == 'no':
        if user_input == "":
             return_value = 0
        elif user_input.isdigit() and (0 < int(user_input) < count):
                return_value = int(user_input)
        else:
            user_input = input("Please select valid number: ")
    
    if return_value == 0:
        return input_files
    else:
        return [input_files[return_value-1]]
    
def sinkholes():
    all_sinkholes = []
    while True:
        print("\nPlease provide any sinkholes by typing them out below (Press enter to move on): ")
        sinkhole = input()
        if sinkhole.strip() == "":
            return all_sinkholes
        print("Does this look correct:", sinkhole)
        first = input("(y/n): ")
        answer = None
        while not answer:
            first = first.lower().strip()
            if first in ['yes', 'no', 'n', 'y']:
                if first in ['yes', 'y']:
                    answer = first.strip()
                else:
                    sinkhole = input("Please type in correct sinkhole: ")
                    print("Does this look correct:", sinkhole)
                    first = input("(y/n): ")
            else:
                first = input("Please use (y/n): ")
        all_sinkholes.append(sinkhole)

def ask_for_amount():
    print("\nHow many domains would you like to test (1-1000)?: ", end="")

    num = input()
    num = num.strip()
    while True:
        if num.isdigit() and (0 < int(num) <= 1000):
                    return int(num)
        else:
             num = input("Please provide a number between 1-1000: ")
             num = num.strip()
