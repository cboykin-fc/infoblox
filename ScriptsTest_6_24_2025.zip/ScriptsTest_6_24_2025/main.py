##########################
# Script by Zachary Miszkiewicz (zmiszkiewicz@infoblox.com)
# Any questions you can reach out to Zachary Miszkiewicz (zmiszkiewicz@infoblox.com)
# Infoblox.com
##########################




import scripts.helper as h
from scripts.Resolve_Domains import main as main2
from scripts.Sinkholing_Out import main as main3
from scripts.Finalized_Results import main as main4


# Lists of IoC
input_files = h.list_files("files")

# Ask User For Sinkholes
sinkhole = h.sinkholes()

# Ask user for timeout amount
timeout = h.ask_for_timeout()

# Which files to use
files = h.main(input_files)

# Ask for how many to query
amount = h.ask_for_amount()

# Begin Query Process
main2(files, sinkhole, amount, timeout)

# Go Through CSV Files and Change Sinkholes to Blocked
main3(sinkhole)

# Gather Results From All Other CSV Files and Create Overall Statistics
main4()
