##########################
# Script by Manu Gonzalez (mgonzalez@infoblox.com), Joaquin Gómez (jgomez@infoblox.com)
# Script edited and changed by Zachary Miszkiewicz (zmiszkiewicz@infoblox.com)
# Infoblox.com
##########################
def main(sinkholes):
    import os
    import csv

    OK = "ALLOWED"
    NOT_OK = "BLOCKED"

    # Get the script location
    try:
        actual_directory = os.path.join(os.getcwd(), 'results')
    except FileNotFoundError:
        return "The folder 'results' does not exist."
    except Exception as e:
        return f"An error occurred: {e}"

    # Infblox Redirect Addresses
    infoblox_redirects = ['3.215.231.251', '3.216.243.225', '35.168.95.233', '54.173.31.46', '3.220.140.235']

    # Base IP address
    ip_base = "146.112."

    # List of suffixes for generating the complete IP addresses
    suffixes = range(1, 255)  # You can adjust the range according to your needs.

    # Create a list with all the complete IP addresses. (146.112.61.* and 146.112.48.*)
    sinkhole_ip = [ip_base + "61." + str(i) for i in suffixes] + [ip_base + "48." + str(i) for i in suffixes]
    for sinkhole in sinkholes:
        sinkhole_ip.append(sinkhole)

    def change_cell_values(csv_file):
        # Read the csv file
        with open(csv_file, 'r') as f:
            rows = list(csv.reader(f))

            # Iterate through rows (Excluding the header)
            for row in rows[1:]:
                ip_cell = row[1]  # Value of the 'IPAddress' column (assuming it is the second column)
                ips_in_cell = ip_cell.split(",")  # Separate IPs 

                # Check if at least one of the IPs is in the list and the status is 'OK'
                status = row[2]  # Value of the 'Status' column (assuming it is the third column)
                if any(ip.strip() in sinkhole_ip for ip in ips_in_cell) and status == OK:
                    row[2] = NOT_OK  # Change the value to "NOT_OK"
                if any(ip.strip() in infoblox_redirects for ip in ips_in_cell) and status == OK:
                    row[2] = NOT_OK  # Change the value to "NOT_OK"
                    row[3] = "Infoblox Redirect Address"
                
                

        # Write the changes to the CSV file
        with open(csv_file, 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerows(rows)
        print(f"Cells have been updated in {csv_file}")

    # Iterate over the CSV files in the current directory.
    for file_csv in os.listdir(actual_directory):
        if file_csv.endswith(".csv"):
            complete_path = os.path.join(actual_directory, file_csv)
            change_cell_values(complete_path)

    print("Process complete.")
