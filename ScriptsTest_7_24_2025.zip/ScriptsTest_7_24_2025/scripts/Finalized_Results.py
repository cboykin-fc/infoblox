##########################
# Script by Manu Gonzalez (mgonzalez@infoblox.com), Joaquin Gómez (jgomez@infoblox.com)
# Script edited and changed by Zachary Miszkiewicz (zmiszkiewicz@infoblox.com)
# Infoblox.com
##########################
import os


def get_unique_file_name(file_path):
    file_name, file_ext = os.path.splitext(file_path)
    counter = 1
    while os.path.exists(file_path):
        file_path = f"{file_name}_{counter}{file_ext}"
        counter += 1
    
    return file_path

def main():
    import os
    import csv

    OK = "ALLOWED"
    NOT_OK = "BLOCKED"

    # Get the path of the directory where the script is executed
    #actual_directory = os.path.dirname(os.path.abspath(__file__))
    try:
        actual_directory = os.path.join(os.getcwd(), 'results')
    except FileNotFoundError:
        return "The folder 'results' does not exist."
    except Exception as e:
        return f"An error occurred: {e}"
    # Dictionary to count rows with 'OK' and 'NOT_OK' values per CSV file.
    file_stats = {}

    # Iterate through the CSV files in the current directory.
    for csv_file in os.listdir(actual_directory):
        if csv_file.endswith(".csv") and not csv_file.startswith("statistics"):
            full_path = os.path.join(actual_directory, csv_file)
            with open(full_path, 'r') as f:
                rows = list(csv.reader(f))
                stats = {OK: 0, NOT_OK: 0}
                for row in rows[1:]:
                    status = row[2]  # Value of the 'Status' column (assuming it is the third column)
                    if status == OK:
                        stats[OK] += 1
                    elif status == NOT_OK:
                        stats[NOT_OK] += 1
                total_rows = stats[OK] + stats[NOT_OK]
                percent_ok = (stats[OK] / total_rows) * 100
                percent_not_ok = (stats[NOT_OK] / total_rows) * 100
                file_stats[csv_file] = {
                    "Allowed": stats[OK],
                    "Blocked": stats[NOT_OK],
                    "Percentage Allowed": f"{percent_ok:.2f}%",
                    "Percentage Blocked": f"{percent_not_ok:.2f}%"
                }
    
    # Create a new CSV with the statistics
    output_file = os.path.join(os.getcwd(), "statistics.csv")
    if os.path.exists(output_file):
        output_file = get_unique_file_name(output_file)

    with open(output_file, 'w', newline='') as file_results:
        writer = csv.writer(file_results)
        writer.writerow(["File", "Allowed", "Blocked", "Percentage Allowed", "Percentage Blocked"])
        for file, stat in file_stats.items():
            writer.writerow([file, stat["Allowed"], stat["Blocked"], stat["Percentage Allowed"], stat["Percentage Blocked"]])

    print("Statistics saved in statistics.csv")

